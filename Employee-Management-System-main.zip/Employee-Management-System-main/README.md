# Employee-Management-System
Django-based Employee Management System: Apps for Employee Info, Attendance, Leave, and Performance. Modular design ensures efficient organization and scalability for employee data and HR processes.
